import java.util.Random;

public class botteghino {
    private int biglietti = 100;
    private int sportelliOccupati = 0;
    private final int max = 5;

    public synchronized boolean compra(String nome) throws InterruptedException {
        if (biglietti == 0) {
            return false;
        }

        while (sportelliOccupati == max) {
            wait();
        }

        sportelliOccupati++;

        Thread.sleep(200 + new Random().nextInt(300));

        if (biglietti > 0) {
            biglietti--;
            System.out.println(nome + " ha comprato un biglietto. Rimasti: " + biglietti);
        }

        sportelliOccupati--;
        notifyAll();

        return true;
    }
}
