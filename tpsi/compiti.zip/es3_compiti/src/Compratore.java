public class Compratore extends Thread {
    private final botteghino botteghino;
    private final String nome;

    public Compratore(botteghino b, String nome) {
        this.botteghino = b;
        this.nome = nome;
    }

    @Override
    public void run() {
        try {
            int attesa = 2000 + (int)(Math.random() * 4000);
            Thread.sleep(attesa);

            boolean preso = botteghino.compra(nome);
            if (!preso) {
                System.out.println(nome + " non ha trovato biglietti.");
            }

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
