public class Main {
    public static void main(String[] args) {
        spogliatoio spogliatoio = new spogliatoio();
        pista pista = new pista();

        for (int i = 1; i <= 8; i++) {
            new pilota("Pilota" + i, spogliatoio, pista).start();
        }
    }
}