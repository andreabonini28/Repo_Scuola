public class pilota extends Thread {
    private final String nome;
    private final spogliatoio spogliatoio;
    private final pista pista;

    public pilota(String nome, spogliatoio s, pista p) {
        this.nome = nome;
        this.spogliatoio = s;
        this.pista = p;
    }

    @Override
    public void run() {
        try {
            spogliatoio.entra(nome);
            int attesa = 1000 + (int)(Math.random() * 4000);
            Thread.sleep(attesa);
            spogliatoio.esci(nome);

            pista.entra(nome);
            for (int i = 1; i <= 15; i++) {
                System.out.println(nome + " fa il giro " + i);
                int attesa2 = 1000 + (int)(Math.random() * 6000);
                Thread.sleep(attesa);
            }
            pista.esci(nome);

            spogliatoio.entra(nome);
            int attesa3= 1000 + (int)(Math.random() * 5000);
            Thread.sleep(attesa);
            spogliatoio.esci(nome);

            System.out.println(nome + " ha finito la gara");

        } catch (InterruptedException e) {
        }
    }
}