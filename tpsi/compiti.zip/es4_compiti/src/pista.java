public class pista {
    private int kartinpista = 0;
    private final int max = 4;

    public synchronized void entra(String nome) throws InterruptedException {
        while (kartinpista == max) {
            wait();
        }
        kartinpista++;
        System.out.println(nome + " entra in pista");
    }

    public synchronized void esci(String nome) {
        kartinpista--;
        System.out.println(nome + " lascia la pista");
        notifyAll();
    }
}