public class spogliatoio {
    private int occupati = 0;
    private final int MAX = 2;

    public synchronized void entra(String nome) throws InterruptedException {
        while (occupati == MAX) {
            wait();
        }
        occupati++;
        System.out.println(nome + " entra nello spogliatoio");
    }

    public synchronized void esci(String nome) {
        occupati--;
        System.out.println(nome + " esce dallo spogliatoio");
        notifyAll();
    }
}