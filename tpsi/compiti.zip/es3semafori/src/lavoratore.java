import java.util.concurrent.Semaphore;

public class lavoratore extends Thread {
    private String nome;
    private Semaphore semaforo;

    public lavoratore (String name, Semaphore semaforo) {
        this.nome = name;
        this.semaforo = semaforo;
    }

    @Override
    public void run () {
        while (true) {
            try {
                semaforo.acquire();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println( nome + " sta lavorando");
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println( nome + " ha finito di lavorare");
            semaforo.release();
        }
    }
}