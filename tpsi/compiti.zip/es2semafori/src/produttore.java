public class produttore extends Thread {
    private final buffer buffer;

    public produttore(buffer b) {
        this.buffer = b;
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= 20; i++) {
                buffer.inserimento(i);
                Thread.sleep(300);
            }
        } catch (InterruptedException e) {
        }
    }
}