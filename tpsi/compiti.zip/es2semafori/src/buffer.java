import java.util.concurrent.Semaphore;

class buffer {
    private final int[] buffer;
    private int scrittura = 0;
    private int lettura = 0;
    private final int size;

    private final Semaphore vuoto;
    private final Semaphore pieno;
    private final Semaphore mutex;

    public buffer(int size) {
        this.size = size;
        this.buffer = new int[size];
        this.vuoto = new Semaphore(size);
        this.pieno = new Semaphore(0);
        this.mutex = new Semaphore(1);
    }

    public void inserimento(int valore) throws InterruptedException {
        vuoto.acquire();
        mutex.acquire();

        buffer[scrittura] = valore;
        scrittura = (scrittura + 1) % size;
        System.out.println("produttore inserisce: " + valore);

        mutex.release();
        pieno.release();
    }

    public int get() throws InterruptedException {
        pieno.acquire();
        mutex.acquire();

        int valore = buffer[lettura];
        lettura = (lettura + 1) % size;
        System.out.println("consumatore preleva: " + valore);

        mutex.release();
        vuoto.release();

        return valore;
    }
}