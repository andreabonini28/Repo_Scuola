public class consumatore extends Thread {
    private final buffer buffer;

    public consumatore(buffer b) {
        this.buffer = b;
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= 20; i++) {
                buffer.get();
                Thread.sleep(500);
            }
        } catch (InterruptedException e) {
        }
    }
}