public class Main {
    public static void main(String[] args) {
        buffer buffer = new buffer(5);
        produttore p = new produttore(buffer);
        consumatore c = new consumatore(buffer);
        p.start();
        c.start();

    }
}