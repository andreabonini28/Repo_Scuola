public class camerino {
    private int capacita;
    private int postioccupati = 0;
    public camerino(int capacita){
        this.capacita = capacita;
    }
    public synchronized void entra(String nome) throws InterruptedException{
        while(postioccupati >= capacita){
            wait();
        }
        postioccupati += 1;
        System.out.println("Il modello "+nome+" è nel camerino");
        int attesa = 1000 + (int)(Math.random() * 2000);
        Thread.sleep(attesa);

        System.out.println(nome + " è uscito dal camerino");
        postioccupati -= 1;
        notifyAll();
    }

}
