public class modello extends Thread{
    private String nome;
    private camerino camerino;
    private passerella passerella;
    public modello(String nome, camerino camerino, passerella passerella){
        this.nome = nome;
        this.camerino = camerino;
        this.passerella = passerella;
    }
    @Override
    public void run(){
        try{
            camerino.entra(nome);
            passerella.sfila(nome);
        }catch (InterruptedException e){
            throw new RuntimeException();
        }
    }
}
