public class passerella {
    private int capacita;
    private int postioccupati = 0;
    public passerella(int capacita){
        this.capacita = capacita;
    }
    public synchronized void sfila(String nome) throws InterruptedException{
        while(postioccupati >= capacita){
            wait();
        }
        postioccupati += 1;
        System.out.println("Il modello "+nome+" sta sfilando");
        int attesa = 1000 + (int)(Math.random() * 2000);
        Thread.sleep(attesa);

        System.out.println("ha impiegato "+(attesa/1000)+" secondi");
        postioccupati -= 1;
        notifyAll();
    }
}
