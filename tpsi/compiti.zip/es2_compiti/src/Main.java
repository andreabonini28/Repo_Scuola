import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
    camerino c = new camerino(7);
    passerella p = new passerella(5);
        ArrayList<modello> modelli = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            modelli.add(new modello(Integer.toString(i), c, p));
        }

        for (modello m : modelli) {
            m.start();
        }
    }
}