import java.util.concurrent.Semaphore;

public class StampaDispari extends Thread {
    private Semaphore semaforopari;
    private Semaphore semaforodispari;

    public StampaDispari (Semaphore smPari, Semaphore smDispari) {
        this.semaforopari = smPari;
        this.semaforodispari = smDispari;
    }

    @Override
    public void run() {
        for (int i = 1; i <= 20; i += 2) {
            try {
                semaforodispari.acquire();
            }catch (InterruptedException e) {
                System.out.println(e.getMessage());
                System.exit(0);
            }
            System.out.println("Dispari: " + i);
            semaforopari.release();
        }
    }
}
