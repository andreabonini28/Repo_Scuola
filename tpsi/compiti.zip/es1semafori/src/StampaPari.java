import java.util.concurrent.Semaphore;

public class StampaPari extends Thread {
    private Semaphore semaforopari;
    private Semaphore semaforodispari;

    public StampaPari (Semaphore smPari, Semaphore smDispari) {
        this.semaforopari = smPari;
        this.semaforodispari = smDispari;
    }

    @Override
    public void run() {
        for (int i = 2; i <= 20; i += 2) {
            try {
                semaforopari.acquire();
            }catch (InterruptedException e) {
                System.out.println(e.getMessage());
                System.exit(0);
            }
            System.out.println("Pari: " + i);
            semaforodispari.release();
        }
    }
}
