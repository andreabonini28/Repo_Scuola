import java.util.concurrent.Semaphore;

public class Main {
    public static void main(String[] args) {
        Semaphore semaforopari = new Semaphore(0);
        Semaphore semaforodispari = new Semaphore(1);

        StampaPari sp = new StampaPari(semaforopari, semaforodispari);
        StampaDispari sd = new StampaDispari(semaforopari, semaforodispari);

        sp.start();
        sd.start();
    }
}