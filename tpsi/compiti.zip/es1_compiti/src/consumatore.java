public class consumatore extends Thread {
    private final magazzino magazzino;

    public consumatore(magazzino m) {
        this.magazzino = m;
    }

    @Override
    public void run() {
        try {
            while (true) {
                magazzino.prelievo();
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
        }
    }
}