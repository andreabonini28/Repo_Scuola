public class Main {
    public static void main(String[] args) {
        magazzino m = new magazzino(10);
        for(int i = 0; i<10;i ++){
            new produttore(m).start();
        }
        for(int i = 0; i <4;i ++){
            new consumatore(m).start();
        }
new ispettore(m,40).start();
    }
}