public class ispettore extends Thread {
    private final magazzino magazzino;
    private final int soglia;

    public ispettore(magazzino m, int soglia) {
        this.magazzino = m;
        this.soglia = soglia;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Thread.sleep(3000);
                magazzino.ispeziona(soglia);
            }
        } catch (InterruptedException e) {
        }
    }
}