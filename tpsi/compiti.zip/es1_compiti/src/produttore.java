public class produttore extends Thread {
    private final magazzino magazzino;
    private int numero = 0;

    public produttore(magazzino m) {
        this.magazzino = m;
    }

    @Override
    public void run() {
        try {
            while (true) {
                magazzino.inserimento(numero);
                numero += 2;
                Thread.sleep(500);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}