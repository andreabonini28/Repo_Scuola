import java.util.ArrayList;

public class magazzino {
    private final int capacita ;
    private ArrayList <Integer> buffer = new ArrayList<>();
    private boolean ispettore = false;

    public magazzino(int capacita){
        this.capacita = capacita;

    }
    public synchronized void inserimento(int numero) throws InterruptedException{
        while(buffer.size() == capacita || ispettore){
            wait();
        }
        buffer.add(numero);
        System.out.println("è stato inserito un numero dal produttore : "+ numero);
        notifyAll();
    }
    public synchronized int prelievo()throws InterruptedException{
        while(buffer.isEmpty() || ispettore){
            wait();
        }
        int numero_prelevato = buffer.removeLast();
        System.out.println("è stato prelevato un numero dal consumatore :"+ numero_prelevato);
        notifyAll();
        return numero_prelevato;
    }
    public synchronized void ispeziona (int x) throws InterruptedException {
        int somma = 0;
        for(int i = 0; i< buffer.size(); i++){
            somma += buffer.get(i);
        }
        if(somma >= x){
            System.out.println(somma);
            buffer.clear();
            somma = 0;

        }else {
            if(!buffer.isEmpty()){
                buffer.set(0,somma);
                somma = 0;
            }else{
                buffer.add(somma);
                somma= 0;
            }
        }
        ispettore= false;
        notifyAll();
    }

}
